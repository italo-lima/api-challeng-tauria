import { Router } from 'express';

const routes = Router();

import usersRoutes from '@modules/users/infra/http/routes/users.routes';
import sessionsRoutes from '@modules/users/infra/http/routes/sessions.routes';
import pizzasRoutes from '@modules/pizzas/infra/http/routes/pizzas.routes';

routes.use('/users', usersRoutes);
routes.use('/sessions', sessionsRoutes);
routes.use('/pizzas', pizzasRoutes);

export default routes;
