import { container } from 'tsyringe';

import IAnimalsRepository from '@modules/users/repositories/IUsersRepository';
import UserRepository from '@modules/users/infra/typeorm/repositories/UserRepository';

import IPizzaRepository from '@modules/pizzas/repositories/IPizzaRepository';
import PizzaRepository from '@modules/pizzas/infra/typeorm/repositories/PizzaRepository';

import '@modules/users/providers';

container.registerSingleton<IAnimalsRepository>(
  'UserRepository',
  UserRepository,
);

container.registerSingleton<IPizzaRepository>(
  'PizzaRepository',
  PizzaRepository,
);
