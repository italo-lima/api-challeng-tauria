import Pizza from '@modules/pizzas/infra/typeorm/entities/Pizza';

import ICreatePizzaDTO from '@modules/pizzas/dtos/ICreatePizzaDTO';

interface IUsersRepository {
  create(data: ICreatePizzaDTO): Promise<Pizza>;
}

export default IUsersRepository;
