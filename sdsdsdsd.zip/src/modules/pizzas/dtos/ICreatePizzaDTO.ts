export default interface ICreatePizzaDTO {
  size: string;
  crust: string;
  ingredients: string;
  toppings: string;
  user: string;
  total: number;
}
