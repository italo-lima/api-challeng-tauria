import { Request, Response } from 'express';
import { container } from 'tsyringe';

import CreateServicePizza from '@modules/pizzas/services/CreateServicePizza';

export default class UsersController {
  public async create(req: Request, res: Response): Promise<Response> {
    const { crust, ingredients, size, toppings, total } = req.body;
    // const user_id = req.user_id.id;

    const pizzaService = container.resolve(CreateServicePizza);

    const pizza = await pizzaService.execute({
      crust,
      ingredients,
      size,
      toppings,
      total,
      user: '0',
    });

    return res.json(pizza);
  }
}
