import { Router } from 'express';

import PizzasController from '@modules/pizzas/infra/http/controllers/PizzasController';
import verifyAuthentication from '@modules/users/infra/http/middlewares/verifyAuthentication';

const pizzasRoutes = Router();
const pizzasController = new PizzasController();

pizzasRoutes.use(verifyAuthentication);

pizzasRoutes.post('/', pizzasController.create);

export default pizzasRoutes;
